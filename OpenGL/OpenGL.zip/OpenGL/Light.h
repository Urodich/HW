#pragma once
#include"Header.h"

class Light {
public:
	vec3 position;
	vec3 color;
	float power;
};